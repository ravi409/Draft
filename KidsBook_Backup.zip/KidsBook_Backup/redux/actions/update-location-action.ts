
export const updateLocation = (data: any) => ({
    type: "UPDATE_LOCATION",
    locationData: data
});
