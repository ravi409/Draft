
export const updateMasterData = (data: any) => ({
    type: "UPDATE_MASTER_DATA",
    masterData: data
});
