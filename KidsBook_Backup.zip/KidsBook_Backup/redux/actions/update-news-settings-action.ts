
export const updateNewsSettings = (data: any) => ({
    type: "UPDATE_NEWS_SETTINGS",
    newsSettings: data
});
