interface NewsSettingsType1 {
    localNews: boolean;
    nationalNews: boolean;
    internationalNews: boolean;
}