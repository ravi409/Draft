import { combineReducers } from 'redux';
import newsSettingsReducer from './news-settings-reducer';
import locationReducer from './location-reducer';
import masterDataReducer from './master-data-reducer';

// Redux: Root Reducer
const rootReducer = combineReducers({  
    masterDataReducer: masterDataReducer,
    newsSettingsReducer:newsSettingsReducer,
    locationReducer:locationReducer
    
});

// Exports
export default rootReducer;