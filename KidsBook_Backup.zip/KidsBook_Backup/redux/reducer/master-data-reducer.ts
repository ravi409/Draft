const initMasterData: {} = {};
const initialState = { masterData: initMasterData };

const masterDataReducer = (state = initialState, action: any) => {
    switch (action.type) {
        case "UPDATE_MASTER_DATA": {
            return { ...state, masterData: action.masterData };
        }
        default: {
            return state;
        }

    }
}
export default masterDataReducer;