import React, { Component } from 'react';
import {
  Image,
  Text,
  View,
  StyleSheet,
  Dimensions,
  StatusBar,
  Platform,
} from 'react-native';
import Constants from 'expo-constants'
import SideSwipe from 'react-native-sideswipe';
import { getFullURL } from '../services/data';
import speak from '../config/tts';
import { connect } from 'react-redux';
import { updateMasterData } from '../redux/actions/update-master-data-action';
import { AnimatedCardItem } from './animated-card-item';

const { width } = Dimensions.get('window');

interface MainState {
  currentIndex: number,
  width: number,
  height: number,
  sectionName: string,
  sectionData: any
}

const mapStateToProps = (state: any) => {
  return {
    masterData: state.masterDataReducer.masterData
  }
}

const mapDispatchToProps = (dispatch: any) => {
  return {
    reduxUpdateMasterData: (masterData: {}) => dispatch(updateMasterData(masterData))
  }
}


export class AnimatedCards extends Component<{
  route: any, navigation: any,
  masterData: any, reduxUpdateMasterData: any
}, Partial<MainState>> {


  constructor(props: any) {
    super(props);
    this.state = {
      currentIndex: 0,
      width: Dimensions.get('window').width,
      height: Dimensions.get('window').height,
      sectionName: this.props.route.params.sectionName,
      sectionData: this.props.masterData[this.props.route.params.sectionName]
    };
    Dimensions.addEventListener("change", (e) => {
      this.setState(e.window);
    });
  }

  cardMove = (index: number) => {
    let flipVoice = this.state.sectionData.cards[index].flipVoice;
    if(flipVoice !=null && flipVoice !=undefined){
      speak(flipVoice);
    }   
  }

  render = () => {
    const offset = (width - AnimatedCardItem.WIDTH) / 2;

    return <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      <Image
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
        }}
        // resizeMode="contain"
        resizeMode='stretch'
        source={{ uri: getFullURL(this.state.sectionName, this.state.sectionData.backgroundImage) }}
      />
      <SideSwipe
        data={this.state.sectionData.cards}
        shouldCapture={() => true}
        style={[styles.fill, { width }]}
        contentContainerStyle={{ paddingTop: 100 }}
        itemWidth={AnimatedCardItem.WIDTH}
        threshold={AnimatedCardItem.WIDTH / 4}
        extractKey={(item: any) => item.frontTitle}
        contentOffset={offset}
        onIndexChange={index => {
          this.setState(() => ({ currentIndex: index }));
          this.cardMove(index);
        }}
        renderItem={({ itemIndex, currentIndex, item, animatedValue }) => (
          <AnimatedCardItem
            planet={item}
            sectionName={this.state.sectionName}
            index={itemIndex}
            currentIndex={currentIndex}
            animatedValue={animatedValue}
          />
        )}
      />

    </View>;
  };
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch',
    justifyContent: 'flex-start',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: 'black',
  },
  fill: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  title: {
    fontFamily: 'dhurjati',
    fontSize: 32,
    color: 'white',
    backgroundColor: 'transparent',
    textAlign: 'center',
    marginTop: 8,
    letterSpacing: 1.6,
    zIndex: 2,
    alignSelf: 'center'
  },
  titlePlatformSpecific: Platform.select({
    ios: {
      marginBottom: 10,
    },
    default: {
      marginBottom: 0,
    }
  }),
});
export default connect(mapStateToProps, mapDispatchToProps)(AnimatedCards);