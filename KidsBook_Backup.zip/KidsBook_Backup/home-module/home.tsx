import React, { Component } from 'react';
import { StyleSheet, Text, TouchableOpacity, Alert } from 'react-native';
import { FlatGrid } from 'react-native-super-grid';
import { Card } from 'react-native-elements';
import speak from '../config/tts';
import { getFullURL, getLatestVersionNumber, getSections } from '../services/data';
import { connect } from 'react-redux';
import { updateMasterData } from '../redux/actions/update-master-data-action';

const mapStateToProps = (state: any) => {
    return {
        masterData: state.masterDataReducer.masterData
    }
}

const mapDispatchToProps = (dispatch: any) => {
    return {
        reduxUpdateMasterData: (masterData: {}) => dispatch(updateMasterData(masterData))
    }
}
const home_path = "home";

export class Home extends Component<{ navigation: { navigate: any }, masterData: any, reduxUpdateMasterData: any }, { masterData: any }> {

    constructor(props: any) {
        super(props);
        this.state = { masterData: this.props.masterData }
    }

    componentDidMount() {
        if (this.props.masterData == null || typeof this.props.masterData == undefined
            || Object.keys(this.props.masterData).length === 0) {
            this.fetchMasterData();
        } else {
            //Compare version number
            getLatestVersionNumber().then(ver => {
                if (ver != this.props.masterData.version) {
                    this.fetchMasterData();
                }
            }, error => {
                Alert.alert('Error', 'Something went wrong');
            });
        }
    }

    fetchMasterData = () => {
        getSections().then(data => {
            this.props.reduxUpdateMasterData(data);
            this.setState({ masterData: data });
        }, error => {
            Alert.alert('Error', 'Something went wrong');
        });
    }

    renderItem = ({ item }: any) => (
        <TouchableOpacity
            onPress={() => this.onClickCard(item)} >
            <Card
                containerStyle={styles.itemContainer}
                imageProps={{ resizeMode: 'stretch' }}
                imageStyle={{ height: 130 }}
                image={{ uri: getFullURL(home_path, item.url) }} >
                <Text style={styles.itemName} >{item.title}</Text>
            </Card>
        </TouchableOpacity>
    );

    onClickCard(item: any) {
        if (item.name in this.state.masterData) {
            speak(item.welcomeVoice);
            this.props.navigation.navigate(item.type, { sectionName: item.name, title: item.title });
            
        } else {
            speak("Apologise for the inconvenience. Unable to open " + item.title + " lesson.");
        }
    }

    keyExtractor = (item: any, index: number) => index.toString()

    render() {
        return (
            <FlatGrid
                itemDimension={130}
                data={this.state.masterData.sections}
                style={styles.gridView}
                spacing={10}
                renderItem={this.renderItem}
            />

        )
    }

}



const styles = StyleSheet.create({
    container: {
        flex: 1,
        resizeMode: 'cover',
    },
    gridView: {
        marginTop: 10,
        flex: 1,
    },
    itemContainer: {
        borderWidth: 0,
        shadowColor: 'rgba(0,0,0, 0.0)',
        backgroundColor: '#191970',
        shadowOffset: { height: 0, width: 0 },
        shadowOpacity: 0,
        shadowRadius: 0,
        elevation: 0,
        height: 170,
    },
    itemName: {
        fontSize: 16,
        color: '#fff',
        fontWeight: '600',
    },
    itemCode: {
        fontWeight: '600',
        fontSize: 12,
        color: '#fff',
    },
});


export default connect(mapStateToProps, mapDispatchToProps)(Home);