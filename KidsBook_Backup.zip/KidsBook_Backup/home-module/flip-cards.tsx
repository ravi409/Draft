import React, { Component } from 'react';
import {
    Text,
    View,
    SafeAreaView,
    Image,
    Dimensions,
    StyleSheet,
    TouchableOpacity, Alert
} from 'react-native';
import CardFlip from 'react-native-card-flip';
import Carousel from 'react-native-snap-carousel';
import speak from '../config/tts';
import { connect } from 'react-redux';
import { updateMasterData } from '../redux/actions/update-master-data-action';
import { getFullURL } from '../services/data';

interface MainState {
    width: number,
    height: number,
    sectionName: string,
    sectionData: any
}

const mapStateToProps = (state: any) => {
    return {
        masterData: state.masterDataReducer.masterData
    }
}

const mapDispatchToProps = (dispatch: any) => {
    return {
        reduxUpdateMasterData: (masterData: {}) => dispatch(updateMasterData(masterData))
    }
}

export class FlipCards extends React.Component<{ route: any, navigation: any, masterData: any, reduxUpdateMasterData: any }, Partial<MainState>> {

    constructor(props: any) {
        super(props);
        this.state = {
            width: Dimensions.get('window').width,
            height: Dimensions.get('window').height,
            sectionName: this.props.route.params.sectionName,
            sectionData: this.props.masterData[this.props.route.params.sectionName]
        };
        Dimensions.addEventListener("change", (e) => {
            this.setState(e.window);
        });
    }


    _flip(card: any, flipVoice: any) {
        card.flip({ direction: 'X' });
        speak(flipVoice);
    }

    _renderItem({ item, index }: any) {
        let card: any = null;
        let itemWidth = (this.state.width ? this.state.width - 10 : 300);
        let itemHeight = this.state.height ? this.state.height / 2 : 250;

        return (
            <View style={{ width: itemWidth, paddingHorizontal: 10 }}>
                <CardFlip style={[styles.itemContainer, { height: (this.state.height) }]}
                    ref={(cd) => card = cd} >

                    <TouchableOpacity style={[styles.itemContainer, { height: itemHeight, backgroundColor: this.state.sectionData.frontBgColor }]}
                        onPress={() => this._flip(card, item.flipVoice)} >
                        {
                            (item.frontTitle != null && item.frontTitle != undefined) &&
                            <Text style={styles.cardTitle} >{item.frontTitle}</Text>
                        }
                        {
                            item.frontText == null || item.frontText == undefined ?
                                <Image source={{ uri: getFullURL(this.state.sectionName, item.frontImage) }}
                                    resizeMode='stretch'
                                    style={{
                                        height: itemHeight, width: itemWidth - 100,
                                        borderRadius: 10,
                                        borderColor: this.state.sectionData.backBgColor,
                                        borderWidth: 0.5,
                                    }}></Image>
                                :
                                <Text style={[styles.itemName,
                                {
                                    color: this.state.sectionData.frontTextColor,
                                    fontSize: this.state.sectionData.frontTextSize
                                }]}>{item.frontText}</Text>
                        }
                    </TouchableOpacity>

                    <TouchableOpacity
                        style={[styles.itemContainer, { height: itemHeight, backgroundColor: this.state.sectionData.backBgColor }]}
                        onPress={() => card.flip()} >
                        {
                            (item.backTitle != null && item.backTitle != undefined) &&
                            <Text style={styles.cardTitle} >{item.backTitle}</Text>
                        }
                        {
                            item.backText == null || item.backText == undefined ?
                                <Image source={{ uri: getFullURL(this.state.sectionName, item.backImage) }}
                                    resizeMode='stretch'
                                    style={{
                                        height: itemHeight, width: itemWidth - 100,
                                        borderRadius: 10,
                                        borderColor: this.state.sectionData.frontBgColor,
                                        borderWidth: 0.5,
                                    }}
                                ></Image>
                                :
                                <Text style={[styles.itemName,
                                {
                                    color: this.state.sectionData.backTextColor,
                                    fontSize: this.state.sectionData.backTextSize
                                }]}
                                >{item.backText}</Text>
                        }
                    </TouchableOpacity>

                </CardFlip>
            </View>
        );
    }

    _carousel: any = null;
    _activeIndex: number = 0;

    render() {
        this._renderItem = this._renderItem.bind(this);

        let itemWidth = (this.state.width ? this.state.width - 80 : 300);

        return (
            <SafeAreaView style={{ flex: 1, backgroundColor: this.state.sectionData.backgroundColor }}>
                <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'center', paddingTop: 50, }}>
                    <Carousel
                        layout={"default"}
                        ref={(ref: any) => this._carousel = ref}
                        data={this.state.sectionData.cards}
                        sliderWidth={itemWidth}
                        itemWidth={itemWidth}
                        renderItem={this._renderItem}
                        onSnapToItem={(index: any) => this._activeIndex = index} />
                </View>
            </SafeAreaView>
        );
    }


}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#ecf0f1',
    },
    itemContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 5,
        padding: 5,
        margin: 20,
    },
    itemName: {
        fontFamily: "Times New Roman",
        fontWeight: '600',
    },
    cardTitle: {
        fontSize: 20,
        fontFamily: "Times New Roman",
        color: '#333',
        fontWeight: '300',
        padding: 5,
    },
    itemCode: {
        fontWeight: '600',
        fontSize: 12,
        color: '#fff',
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(FlipCards);


