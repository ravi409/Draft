import React, { Component } from 'react';
import {
  Animated,
  Image,
  Text,
  View,
  StyleSheet,
  Dimensions,
  StatusBar,
  Platform,
} from 'react-native';
import Constants from 'expo-constants'
import SideSwipe from 'react-native-sideswipe';
import { getFullURL } from '../services/data';
import speak from '../config/tts';
import { connect } from 'react-redux';
import { updateMasterData } from '../redux/actions/update-master-data-action';


const { height, width } = Dimensions.get('window');
const { width: screenWidth } = Dimensions.get('window');
const cardWidth = screenWidth - 50;


interface MainState {
  currentIndex: number,
  width: number,
  height: number,
  sectionName: string,
  sectionData: any
}

const mapStateToProps = (state: any) => {
  return {
    masterData: state.masterDataReducer.masterData
  }
}

const mapDispatchToProps = (dispatch: any) => {
  return {
    reduxUpdateMasterData: (masterData: {}) => dispatch(updateMasterData(masterData))
  }
}

export function CardItem(props: { animatedValue: any, sectionName: any, planet: any, index: number, currentIndex: number }) {
  const { animatedValue, sectionName, planet, index } = props;
  return (
    <Animated.View style={styles.cardContainer}>
      <Animated.Image
        style={[
          styles.planet
        ]}
        source={{ uri: getFullURL(sectionName, planet.frontImage) }}
      />
    </Animated.View>
  );
}


export class TransparentCards extends Component<{
  route: any, navigation: any,
  masterData: any, reduxUpdateMasterData: any
}, Partial<MainState>> {


  constructor(props: any) {
    super(props);
    this.state = {
      currentIndex: 0,
      width: Dimensions.get('window').width,
      height: Dimensions.get('window').height,
      sectionName: this.props.route.params.sectionName,
      sectionData: this.props.masterData[this.props.route.params.sectionName]
    };
    Dimensions.addEventListener("change", (e) => {
      this.setState(e.window);
    });
  }

  cardMove = (index: number) => {
    let flipVoice = this.state.sectionData.cards[index].flipVoice;
    if (flipVoice != null && flipVoice != undefined) {
      speak(flipVoice);
    }
  }

  render = () => {
    const offset = (width - cardWidth) / 2;

    return <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      <Image
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
        }}
        // resizeMode="contain"
        resizeMode='stretch'
        source={{ uri: getFullURL(this.state.sectionName, this.state.sectionData.backgroundImage) }}
      />
      <SideSwipe
        data={this.state.sectionData.cards}
        shouldCapture={() => true}
        style={[styles.fill, { width }]}
        contentContainerStyle={{ paddingTop: 100 }}
        itemWidth={cardWidth}
        threshold={cardWidth / 4}
        extractKey={(item: any) => item.frontTitle}
        contentOffset={offset}
        onIndexChange={index => {
          this.setState(() => ({ currentIndex: index }));
          this.cardMove(index);
        }}
        renderItem={({ itemIndex, currentIndex, item, animatedValue }) => (
          <CardItem
            planet={item}
            sectionName={this.state.sectionName}
            index={itemIndex}
            currentIndex={currentIndex}
            animatedValue={animatedValue}
          />
        )}
      />

    </View>;
  };
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch',
    justifyContent: 'flex-start',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: 'black',
  },
  cardContainer: {
    width: width,
    height: width,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'visible',
  },
  fill: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  title: {
    fontFamily: 'dhurjati',
    fontSize: 32,
    color: 'white',
    backgroundColor: 'transparent',
    textAlign: 'center',
    marginTop: 8,
    letterSpacing: 1.6,
    zIndex: 2,
    alignSelf: 'center'
  },
  titlePlatformSpecific: Platform.select({
    ios: {
      marginBottom: 10,
    },
    default: {
      marginBottom: 0,
    }
  }),
  planet: Platform.select({
    ios: {
      width: cardWidth - 25,
      height: cardWidth - 25,
    },
    android: {
      width: cardWidth - 50,
      height: cardWidth - 50,
    },
    default: {
      width: cardWidth - 50,
      height: cardWidth - 50  ,
    },
  }),
  cardTitle: Platform.select({
    ios: {
      fontSize: 32,
      position: 'absolute',
      top: -30,
      textAlign: 'center',
      fontWeight: 'bold',
      letterSpacing: 1.2,
      color: 'white',
      backgroundColor: 'transparent',
    },
    android: {
      fontSize: 24,
      position: 'absolute',
      top: -30,
      textAlign: 'center',
      fontWeight: 'bold',
      letterSpacing: 1.2,
      color: 'white',
      backgroundColor: 'transparent',
    },
    default: {
      fontSize: 24,
      position: 'absolute',
      top: -30,
      textAlign: 'center',
      fontWeight: 'bold',
      letterSpacing: 1.2,
      color: 'white',
      backgroundColor: 'transparent',
    }
  }),
});
export default connect(mapStateToProps, mapDispatchToProps)(TransparentCards);