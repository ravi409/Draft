import animalsImages from "./animals-images";

export default [

    {
        name: 'Ant',
        description: '',
        url: animalsImages.ant
    }, {
        name: 'Alligator',
        description: '',
        url: animalsImages.alligator
    },
    {
        name: 'Bat',
        description: '',
        url: animalsImages.bat
    },
    {
        name: 'Bear',
        description: '',
        url: animalsImages.bear
    },
    {
        name: 'Bee',
        description: '',
        url: animalsImages.bee
    },
    {
        name: 'Butterfly',
        description: '',
        url: animalsImages.butterfly
    },
    {
        name: 'Camel',
        description: '',
        url: animalsImages.camel
    },
    {
        name: 'Cat',
        description: '',
        url: animalsImages.cat
    },
    {
        name: 'Caterpillar',
        description: '',
        url: animalsImages.caterpillar
    },
    {
        name: 'Chimpangee',
        description: '',
        url: animalsImages.chimpangee
    },
    {
        name: 'Crow',
        description: '',
        url: animalsImages.crow
    },
    {
        name: 'Deer',
        description: '',
        url: animalsImages.deer
    },
    {
        name: 'Dinosaur',
        description: '',
        url: animalsImages.dinosaur
    },
    {
        name: 'Dog',
        description: '',
        url: animalsImages.dog
    },
    {
        name: 'Dolphin',
        description: '',
        url: animalsImages.dolphin
    },
    {
        name: 'Donkey',
        description: '',
        url: animalsImages.donkey
    },
    {
        name: 'Dove',
        description: '',
        url: animalsImages.dove
    },
    {
        name: 'Dragon Fly',
        description: '',
        url: animalsImages.dragon_fly
    },
    {
        name: 'Duck',
        description: '',
        url: animalsImages.duck
    },
    {
        name: 'Eagle',
        description: '',
        url: animalsImages.eagle
    },
    {
        name: 'Elephant',
        description: '',
        url: animalsImages.elephant
    },
    {
        name: 'Fish',
        description: '',
        url: animalsImages.fish
    },
    {
        name: 'Fly',
        description: '',
        url: animalsImages.fly
    },
    {
        name: 'Fox',
        description: '',
        url: animalsImages.fox
    },
    {
        name: 'Frog',
        description: '',
        url: animalsImages.frog
    },
    {
        name: 'Giraffe',
        description: '',
        url: animalsImages.giraffe
    },
    {
        name: 'Goat',
        description: '',
        url: animalsImages.goat
    },
    {
        name: 'Gorilla',
        description: '',
        url: animalsImages.gorilla
    },
    {
        name: 'Hippopotamus',
        description: '',
        url: animalsImages.hippopotamus
    },
    {
        name: 'Horse',
        description: '',
        url: animalsImages.horse
    },
    {
        name: 'Iguana',
        description: '',
        url: animalsImages.iguana
    },
    {
        name: 'Jagwar',
        description: '',
        url: animalsImages.jagwar
    },
    {
        name: 'Kangaroo',
        description: '',
        url: animalsImages.kangaroo
    },
    {
        name: 'Lion',
        description: '',
        url: animalsImages.lion
    },
    {
        name: 'Monkey',
        description: '',
        url: animalsImages.monkey
    },
    {
        name: 'Mouse',
        description: '',
        url: animalsImages.mouse
    },
    {
        name: 'Nightingale',
        description: '',
        url: animalsImages.nightingale
    },
    {
        name: 'Ostrich',
        description: '',
        url: animalsImages.ostrich
    },
    {
        name: 'Owl',
        description: '',
        url: animalsImages.owl
    },
    {
        name: 'Ox',
        description: '',
        url: animalsImages.ox
    },
    {
        name: 'Parrot',
        description: '',
        url: animalsImages.parrot
    },
    {
        name: 'Peacock',
        description: '',
        url: animalsImages.peacock
    },
    {
        name: 'Pig',
        description: '',
        url: animalsImages.pig
    },
    {
        name: 'Pigeon',
        description: '',
        url: animalsImages.pigeon
    },
    {
        name: 'Quail',
        description: '',
        url: animalsImages.quail
    },
    {
        name: 'Rabbit',
        description: '',
        url: animalsImages.rabbit
    },
    {
        name: 'Rhinoceros',
        description: '',
        url: animalsImages.rhinoceros
    },
    {
        name: 'Shark',
        description: '',
        url: animalsImages.shark
    },
    {
        name: 'Sheep',
        description: '',
        url: animalsImages.sheep
    },
    {
        name: 'Snake',
        description: '',
        url: animalsImages.snake
    },
    {
        name: 'Spider',
        description: '',
        url: animalsImages.spider
    },
    {
        name: 'Squirrel',
        description: '',
        url: animalsImages.squirrel
    },
    {
        name: 'Swan',
        description: '',
        url: animalsImages.swan
    },
    {
        name: 'Tiger',
        description: '',
        url: animalsImages.tiger
    },
    {
        name: 'Unicorn',
        description: '',
        url: animalsImages.unicorn
    },
    {
        name: 'Vulture',
        description: '',
        url: animalsImages.vulture
    },
    {
        name: 'Wolf',
        description: '',
        url: animalsImages.wolf
    },
    {
        name: 'Yak',
        description: '',
        url: animalsImages.yak
    },
    {
        name: 'Zebra',
        description: '',
        url: animalsImages.zebra
    },
];