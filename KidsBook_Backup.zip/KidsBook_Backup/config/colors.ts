export default [
  {
    name: 'Yellow',
    code: '#FFFF00'
  },
  {
    name: 'Red',
    code: '#FF0000'
  },
  {
    name: 'Green',
    code: '#008000'
  },
  {
    name: 'Orange',
    code: '#FFA500'
  }, {
    name: 'Blue',
    code: '#0000FF'
  }, {
    name: 'Pink',
    code: '#FFC0CB'
  }, {
    name: 'Purple',
    code: '#800080'
  }, {
    name: 'White',
    code: '#FFFFFF'
  }, {
    name: 'Brown',
    code: '#A52A2A'
  }, {
    name: 'Black',
    code: '#000000'
  }
];
