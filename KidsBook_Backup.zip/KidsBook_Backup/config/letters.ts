import capabcImages from "./capabc-images";


export default [

  {
    name: 'A',
    description: 'Apple',
    url: capabcImages.apple
  },
  {
    name: 'B',
    description: 'Ball',
    url: capabcImages.ball
  },
  {
    name: 'C',
    description: 'Car',
    url: capabcImages.car
  },
  {
    name: 'D',
    description: 'Dog',
    url: capabcImages.dog
  },
  {
    name: 'E',
    description: 'Elephant',
    url: capabcImages.elephant
  },
  {
    name: 'F',
    description: 'Fish',
    url: capabcImages.fish
  },
  {
    name: 'G',
    description: 'Goat',
    url: capabcImages.goat
  },
  {
    name: 'H',
    description: 'Horse',
    url: capabcImages.horse
  },
  {
    name: 'I',
    description: 'Ice Cream',
    url: capabcImages.icecream
  },
  {
    name: 'J',
    description: 'Jug',
    url: capabcImages.jug
  },
  {
    name: 'K',
    description: 'Kite',
    url: capabcImages.kite
  },
  {
    name: 'L',
    description: 'Lion',
    url: capabcImages.lion
  },
  {
    name: 'M',
    description: 'Mango',
    url: capabcImages.mango
  },
  {
    name: 'N',
    description: 'Nest',
    url: capabcImages.nest
  },
  {
    name: 'O',
    description: 'Ostrich',
    url: capabcImages.ostrich
  },
  {
    name: 'P',
    description: 'Parrot',
    url: capabcImages.parrot
  },
  {
    name: 'Q',
    description: 'Queen',
    url: capabcImages.queen
  },
  {
    name: 'R',
    description: 'Rabbit',
    url: capabcImages.rabbit
  },
  {
    name: 'S',
    description: 'Sun',
    url: capabcImages.sun
  },
  {
    name: 'T',
    description: 'Tiger',
    url: capabcImages.tiger
  },
  {
    name: 'U',
    description: 'Umbrella',
    url: capabcImages.umbrella
  },
  {
    name: 'V',
    description: 'Violin',
    url: capabcImages.violin
  },
  {
    name: 'W',
    description: 'Watch',
    url: capabcImages.watch
  },
  {
    name: 'X',
    description: 'Xray',
    url: capabcImages.xray
  },
  {
    name: 'Y',
    description: 'Yak',
    url: capabcImages.yak
  },
  {
    name: 'Z',
    description: 'Zebra',
    url: capabcImages.zebra
  }

];
