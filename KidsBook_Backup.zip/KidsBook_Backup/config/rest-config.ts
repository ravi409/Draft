export const sections_url  = "https://kidsbook-store.firebaseio.com/.json";
export const version_url  = "https://kidsbook-store.firebaseio.com/version.json";

export const articles_url = 'http://newsapi.org/v2/top-headlines';
export const sources_url = 'http://newsapi.org/v2/sources?country=in';
export const api_key = '53965b53222240edae1b97e6d3f66395';
export const location_data_url = 'https://pincode-db.firebaseio.com/location';
