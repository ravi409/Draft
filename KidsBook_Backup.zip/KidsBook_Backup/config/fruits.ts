import fruitsImages from "./fruits-images";


export default [
    {
        name: 'Apple',
        description: 'Apple',
        url: fruitsImages.apple
    },
    {
        name: 'Avocado',
        description: 'Avocado',
        url: fruitsImages.avocado
    },
    {
        name: 'Banana',
        description: 'Banana',
        url: fruitsImages.banana
    },
    {
        name: 'Blueberry',
        description: 'Blueberry',
        url: fruitsImages.blueberry
    },
    {
        name: 'Cherry',
        description: 'Cherry',
        url: fruitsImages.cherry
    },
    {
        name: 'Chikoo',
        description: 'Chikoo',
        url: fruitsImages.chikoo
    },
    {
        name: 'Custard Apple',
        description: 'Custard Apple',
        url: fruitsImages.custard_apple
    },
    {
        name: 'Dragon Fruit',
        description: 'Dragon Fruit',
        url: fruitsImages.dragon_fruit
    },
    {
        name: 'Grapes',
        description: 'Grapes',
        url: fruitsImages.grapes
    },
    {
        name: 'Guava',
        description: 'Guava',
        url: fruitsImages.guava
    },
    {
        name: 'Jackfruit',
        description: 'Jackfruit',
        url: fruitsImages.jackfruit
    },
    {
        name: 'Kiwi',
        description: 'Kiwi',
        url: fruitsImages.kiwi
    },
    {
        name: 'Lemon',
        description: 'Lemon',
        url: fruitsImages.lemon
    },
    {
        name: 'Lychee',
        description: 'Lychee',
        url: fruitsImages.lychee
    },
    {
        name: 'Mango',
        description: 'Mango',
        url: fruitsImages.mango
    },
    {
        name: 'Muskmelon',
        description: 'Muskmelon',
        url: fruitsImages.muskmelon
    },
    {
        name: 'Orange',
        description: 'Orange',
        url: fruitsImages.orange
    },
    {
        name: 'Papaya',
        description: 'Papaya',
        url: fruitsImages.papaya
    },
    {
        name: 'Pear',
        description: 'Pear',
        url: fruitsImages.pear
    },
    {
        name: 'Pineapple',
        description: 'Pineapple',
        url: fruitsImages.pineapple
    },
    {
        name: 'Plum',
        description: 'Plum',
        url: fruitsImages.plum
    },
    {
        name: 'Pomegrenate',
        description: 'Pomegrenate',
        url: fruitsImages.pomegrenate
    },
    {
        name: 'Raspberry',
        description: 'Raspberry',
        url: fruitsImages.raspberry
    },
    {
        name: 'Strawberry',
        description: 'Strawberry',
        url: fruitsImages.strawberry
    },
    {
        name: 'Watermelon',
        description: 'Watermelon',
        url: fruitsImages.watermelon
    },

];