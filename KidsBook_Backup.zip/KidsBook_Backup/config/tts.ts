import * as Speech from 'expo-speech';

export default function speak(text:string){   
    Speech.speak(text, {rate:0.8});
};