export default {
    colors:  require('../assets/home/colors.jpg'),
    planets:  require('../assets/home/planets.jpg'),
    capabc:  require('../assets/home/cap_abc.jpg'),
    smallabc:  require('../assets/home/small_abc.jpg'),
    numbers:  require('../assets/home/numbers.jpg'),
    telugu:  require('../assets/home/telugu.jpg'),
    shapes:  require('../assets/home/shapes.jpg'),
    animals:  require('../assets/home/animals.jpg'),
    fruits:  require('../assets/home/fruits.jpg'),
    vegetables:  require('../assets/home/vegetables.jpg'),
    appbackground :  require('../assets/home/app_background.jpg'),
}