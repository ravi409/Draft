import animalsImages from "./animals-images";
import vegetablesImages from "./vegetables-images";

export default [
    {
        name: 'Beetroot',
        description: '',
        url: vegetablesImages.beetroot
    },
    {
        name: 'Bell Peppers',
        description: '',
        url: vegetablesImages.bell_peppers
    },
    {
        name: 'Bitter Gourd',
        description: '',
        url: vegetablesImages.bitter_gourd
    },
    {
        name: 'Bottle Gourd',
        description: '',
        url: vegetablesImages.bottle_gourd
    },
    {
        name: 'Broccoli',
        description: '',
        url: vegetablesImages.broccoli
    },
    {
        name: 'Cabbage',
        description: '',
        url: vegetablesImages.cabbage
    },
    {
        name: 'Carrot',
        description: '',
        url: vegetablesImages.carrot
    },
    {
        name: 'Cauliflower',
        description: '',
        url: vegetablesImages.cauliflower
    },
    {
        name: 'Chilli',
        description: '',
        url: vegetablesImages.chilli
    },
    {
        name: 'Cilantro',
        description: '',
        url: vegetablesImages.cilantro
    },
    {
        name: 'Corn',
        description: '',
        url: vegetablesImages.corn
    },
    {
        name: 'Cucumber',
        description: '',
        url: vegetablesImages.cucumber
    },
    {
        name: 'Curry Leaves',
        description: '',
        url: vegetablesImages.curry_leaves
    },
    {
        name: 'Drumstick',
        description: '',
        url: vegetablesImages.drumstick
    },
    {
        name: 'Eggplant',
        description: '',
        url: vegetablesImages.eggplant
    },
    {
        name: 'Garlic',
        description: '',
        url: vegetablesImages.garlic
    },
    {
        name: 'Ginger',
        description: '',
        url: vegetablesImages.ginger
    },
    {
        name: 'Green Beans',
        description: '',
        url: vegetablesImages.green_beans
    },
    {
        name: 'Ivy Gourd',
        description: '',
        url: vegetablesImages.ivy_gourd
    },
    {
        name: 'Lady Finger',
        description: '',
        url: vegetablesImages.lady_finger
    },
    {
        name: 'Mushroom',
        description: '',
        url: vegetablesImages.mushroom
    },
    {
        name: 'Onion',
        description: '',
        url: vegetablesImages.onion
    },
    {
        name: 'Peas',
        description: '',
        url: vegetablesImages.peas
    },
    {
        name: 'Potato',
        description: '',
        url: vegetablesImages.potato
    },
    {
        name: 'Pumpkin',
        description: '',
        url: vegetablesImages.pumpkin
    },
    {
        name: 'Radish',
        description: '',
        url: vegetablesImages.radish
    },
    {
        name: 'Ridge Gourd',
        description: '',
        url: vegetablesImages.ridge_gourd
    },
    {
        name: 'Roselle',
        description: '',
        url: vegetablesImages.roselle
    },
    {
        name: 'Snake Gourd',
        description: '',
        url: vegetablesImages.snake_gourd
    },
    {
        name: 'Spinach',
        description: '',
        url: vegetablesImages.spinach
    },
    {
        name: 'Tomato',
        description: '',
        url: vegetablesImages.tomato
    },

];