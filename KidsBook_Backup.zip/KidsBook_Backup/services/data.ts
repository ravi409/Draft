import { location_data_url, sections_url,version_url } from '../config/rest-config';

const root_url ="https://firebasestorage.googleapis.com/v0/b/";
const bucket_name = "kidsbook-store.appspot.com/o/";

export function getFullURL(folder: any, image_name: string) {
    if(image_name.startsWith("https://") || image_name.startsWith("http://")){
        return image_name;
    }else{
        return root_url + bucket_name + folder + '%2F' + image_name + '?alt=media';
    }    
}

export async function getLatestVersionNumber() {
    try {
        let ver = await fetch(`${version_url}`);
        return await ver.json();
    } catch (error) {
        throw error;
    }
}

export async function getSections() {
    try {
        let sections = await fetch(`${sections_url}`);
        return await sections.json();
    } catch (error) {
        throw error;
    }
}

export async function getDistricts(state: string) {
    try {
        let districts = await fetch(`${location_data_url}/${state}.json?shallow=true`);
        let result = await districts.json();
        return Object.keys(result).sort();
    } catch (error) {
        throw error;
    }
}

export async function getSubDistricts(state: string, district: string) {
    try {
        let subdistricts = await fetch(`${location_data_url}/${state}/${district}.json?shallow=true`);
        let result = await subdistricts.json();
        return Object.keys(result).sort();
    } catch (error) {
        throw error;
    }
}

export async function getCities(state: string, district: string, subdistrict: string) {
    try {
        let cities = await fetch(`${location_data_url}/${state}/${district}/${subdistrict}.json?shallow=true`);
        let result = await cities.json();
        return Object.keys(result).sort();
    } catch (error) {
        throw error;
    }
}

