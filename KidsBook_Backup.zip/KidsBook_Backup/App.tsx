import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { PersistGate } from 'redux-persist/es/integration/react';
import { Provider } from 'react-redux';
import { store, persistor } from './redux/store/store';
import Home from './home-module/home';
import { createStackNavigator, Header } from '@react-navigation/stack';
// import PlanetSideSwipe from './planets-module/planet-side-swipe';
// import NumberCards from './card-module/number-cards';
// import CapLettersCards from './card-module/cap-letters-cards';
// import ColorCards from './card-module/color-cards';
// import SmallLettersCards from './card-module/small-letters-cards';
// import AnimalsCards from './card-module/animals-cards';
// import FruitsCards from './card-module/fruits-cards';
// import VegetablesCards from './card-module/vegetables-cards';
// import TeluguLettersCards from './card-module/telugu-letters-cards';
import { View, StyleSheet, Image } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import FlipCards from './home-module/flip-cards';
import AnimatedCards  from './home-module/animated-cards';
import TransparentCards  from './home-module/transparent-cards';

const Stack = createStackNavigator();



const GradientHeader = (props: any) => (
  <View style={{ backgroundColor: '#eee' }}>
    <LinearGradient
      colors={['#4c669f', '#3b5998', '#192f6a']}
      style={StyleSheet.absoluteFill}
    />
    <Header {...props} />
  </View>
);

export default function App() {
  return (
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <NavigationContainer >
          <Stack.Navigator screenOptions={{
            headerTintColor: '#fff',
            headerTitleStyle: {
              fontWeight: 'bold',
            },
            headerStyle: { backgroundColor: 'transparent' },
            header: (props) => <GradientHeader {...props} />
          }}  >
            <Stack.Screen
              name="Home"
              component={Home}
              options={{ title: 'Kids Book', cardStyle: { backgroundColor: '#B0C4DE' } }}
            />
            <Stack.Screen
              name="FlipCards"
              component={FlipCards}
              options={({ route }:any) => ({ title: route.params.title })}
            />
            <Stack.Screen
              name="AnimatedCards"
              component={AnimatedCards}
              options={({ route }:any) => ({ title: route.params.title })}
            />
              <Stack.Screen
              name="TransparentCards"
              component={TransparentCards}
              options={({ route }:any) => ({ title: route.params.title })}
            />


            {/* <Stack.Screen
              name="ABC"
              component={CapLettersCards}
              options={{ title: 'ABC' }}
            />
            <Stack.Screen
              name="abc"
              component={SmallLettersCards}
              options={{ title: 'abc' }}
            />
            <Stack.Screen
              name="తెలుగు"
              component={TeluguLettersCards}
              options={{ title: 'తెలుగు' }}
            />
            <Stack.Screen
              name="Numbers"
              component={NumberCards}
              options={{ title: 'Numbers' }}
            />
            <Stack.Screen
              name="Animals"
              component={AnimalsCards}
              options={{ title: 'Animals' }}
            />
            <Stack.Screen
              name="Fruits"
              component={FruitsCards}
              options={{ title: 'Fruits' }}
            />
            <Stack.Screen
              name="Vegetables"
              component={VegetablesCards}
              options={{ title: 'Vegetables' }}
            />
            <Stack.Screen
              name="Planets"
              component={PlanetSideSwipe}
              options={{ title: 'Planets' }}
            />
            <Stack.Screen
              name="Colors"
              component={ColorCards}
              options={{ title: 'Colors' }}
            /> */}
          </Stack.Navigator>
        </NavigationContainer>
      </PersistGate>
    </Provider>
  );
}
