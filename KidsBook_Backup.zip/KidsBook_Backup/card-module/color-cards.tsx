import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    SafeAreaView,
    Dimensions,
    TouchableOpacity
} from 'react-native';

import Carousel from 'react-native-snap-carousel';
import colors from '../config/colors';
import { Card } from 'react-native-elements';
import speak from '../config/tts';

export default class ColorCards extends React.Component<{}, Partial<{ width: number, height: number }>> {


    constructor(props: any) {
        super(props);
        this.state = {
            width: Dimensions.get('window').width,
            height: Dimensions.get('window').height,
        };
        Dimensions.addEventListener("change", (e) => {
            this.setState(e.window);
        });
    }
    carouselItems = colors;

    _renderItem({ item, index }: any) {
        let itemWidth = (this.state.width ? this.state.width - 10 : 300);
        let itemHeight = this.state.height ? this.state.height / 2 : 250;
        return (
            <View style={{ width: itemWidth, paddingHorizontal: 10 }}>
                <Text
                    style={[styles.itemName, { justifyContent: "center", alignSelf: "center" }]}
                >{item.name}</Text>

                <TouchableOpacity
                    onPress={() => speak(item.name)} >

                    <Card
                        containerStyle={{
                            backgroundColor: item.code,
                            justifyContent: 'center',
                            alignItems: 'center',
                            borderRadius: 5,
                            height: itemHeight,
                            padding: 50,
                            marginLeft: 25,
                            marginRight: 25,
                        }}

                    >
                    </Card>
                </TouchableOpacity>
            </View>

        )
    }
    _carousel: any = null;
    _activeIndex: number = 0;

    render() {
        this._renderItem = this._renderItem.bind(this);

        let itemWidth = (this.state.width ? this.state.width - 80 : 300);
        return (
            <SafeAreaView style={{ flex: 1, backgroundColor: 'floralwhite', }}>
                <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'center', paddingTop: 50, }}>
                    <Carousel
                        layout={"default"}
                        ref={(ref: any) => this._carousel = ref}
                        data={this.carouselItems}
                        sliderWidth={itemWidth}
                        itemWidth={itemWidth}
                        renderItem={this._renderItem}
                        onSnapToItem={(index: any) => this._activeIndex = index} />
                </View>
            </SafeAreaView>
        );
    }
}

const styles = StyleSheet.create({
    itemName: {
        fontSize: 16,
        color: '#333',
        fontWeight: '500',
    },
});

