import React, { Component } from 'react';
import {
    Text,
    View,
    SafeAreaView,
    Platform,
    Image,
    Dimensions,
    StyleSheet,
    TouchableOpacity
} from 'react-native';
import CardFlip from 'react-native-card-flip';
import Carousel from 'react-native-snap-carousel';
import letters from '../config/letters';
import speak from '../config/tts';


export default class CapLettersCards extends React.Component<{}, Partial<{ width: number, height: number }>> {


    constructor(props: any) {
        super(props);
        this.state = {
            width: Dimensions.get('window').width,
            height: Dimensions.get('window').height,
        };
        Dimensions.addEventListener("change", (e) => {
            this.setState(e.window);
        });
    }

    carouselItems = letters;

    _flip(card:any,name:string, descr:string ){
        card.flip({ direction: 'X' });
        speak(name + " for " + descr);
    }

    _renderItem({ item, index }: any) {
        let card: any = null;
        let itemWidth = (this.state.width ? this.state.width -10 : 300);
        let itemHeight =this.state.height ? this.state.height/2 : 250;

        return (
            <View style={{ width:itemWidth , paddingHorizontal: 10 }}>
            <CardFlip style={[styles.itemContainer, { height: (this.state.height) }]}
                ref={(cd) => card = cd} >
                <TouchableOpacity style={[styles.itemContainer, { height: itemHeight, backgroundColor: '#1abc9c' }]}
                    onPress={() => this._flip(card,item.name,item.description)} >
                    <Text style={styles.itemName}>{item.name}</Text></TouchableOpacity>
                <TouchableOpacity                
                 style={[styles.itemContainer, { height: itemHeight }]}
                    onPress={() => card.flip()} >
                        <Image source={item.url}   
                            resizeMode='stretch'
                            style={{height:itemHeight,width:itemWidth-100, 
                                borderRadius:10,
                                borderColor:"#1abc9c",
                                borderWidth: 0.5,
                            }}
                        ></Image>
                    </TouchableOpacity>

            </CardFlip>
        </View>
        );
    }

    _renderFrontCard({ item, index }: any) {
        return (
            <View
                style={{
                    backgroundColor: 'floralwhite',
                    justifyContent: 'center',
                    alignItems: 'center',
                    borderRadius: 5,
                    height: (this.state.height ? this.state.height * 0.60 : 250),
                    padding: 30,
                    marginLeft: 25,
                    marginRight: 25,
                }}>
                <Text style={{ fontSize: 100 }}>{item}</Text>
                <Text>{item.text}</Text>
            </View>

        )
    }
    _carousel: any = null;
    _activeIndex: number = 0;

    render() {
        this._renderItem = this._renderItem.bind(this);
        
        let itemWidth = (this.state.width ? this.state.width -80 : 300);

        return (
            <SafeAreaView style={{ flex: 1, backgroundColor: '#E6E6FA', }}>
                <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'center', paddingTop: 50, }}>
                    <Carousel
                        layout={"default"}
                        ref={(ref: any) => this._carousel = ref}
                        data={this.carouselItems}
                        sliderWidth={itemWidth}
                        itemWidth={itemWidth}
                        renderItem={this._renderItem}
                        onSnapToItem={(index: any) => this._activeIndex = index} />
                </View>
            </SafeAreaView>
        );
    }
    

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#ecf0f1',
    },
    itemContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 5,
        padding: 5,
        margin: 20,
    },
    itemName: {
        fontSize: 70,
        fontFamily: "Times New Roman",
        color: '#fff',
        fontWeight: '600',
    },
    itemCode: {
        fontWeight: '600',
        fontSize: 12,
        color: '#fff',
    },
});



