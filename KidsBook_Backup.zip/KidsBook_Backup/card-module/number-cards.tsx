import React, { Component } from 'react';
import {
    Text,
    View,
    SafeAreaView
} from 'react-native';

import Carousel from 'react-native-snap-carousel';

export default class NumberCards extends React.Component {


    constructor(props: any) {
        super(props);
    }
    carouselItems = Array.from({length:50},(x,i) => i+1)

    _renderItem({ item, index }: any) {
        return (
            <View style={{
                backgroundColor: 'floralwhite',
                justifyContent:'center',
                alignItems: 'center',
                borderRadius: 5,
                height: 250,
                padding: 50,
                marginLeft: 25,
                marginRight: 25,
            }}>
                <Text style={{ fontSize: 100 }}>{item}</Text>
                <Text>{item.text}</Text>
            </View>

        )
    }
    _carousel: any = null;
    _activeIndex: number = 0;

    render() {

        return (
            <SafeAreaView style={{ flex: 1, backgroundColor: 'rebeccapurple', }}>
                <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'center', paddingTop: 100, }}>
                    <Carousel
                        layout={"default"}
                        ref={(ref: any) => this._carousel = ref}
                        data={this.carouselItems}
                        sliderWidth={300}
                        itemWidth={300}
                        renderItem={this._renderItem}
                        onSnapToItem={(index: any) => this._activeIndex=index} />
                </View>
            </SafeAreaView>
        );
    }
}



